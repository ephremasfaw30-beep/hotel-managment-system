package com.hotel.dao;

import com.hotel.model.Booking;
import com.hotel.util.DatabaseUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BookingDAO {
    public void addBooking(Booking booking) throws SQLException {
        String sql = "INSERT INTO bookings (guest_id, room_id, check_in_date, check_out_date, total_amount, status) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, booking.getGuestId());
            pstmt.setInt(2, booking.getRoomId());
            pstmt.setString(3, booking.getCheckInDate().toString());
            pstmt.setString(4, booking.getCheckOutDate().toString());
            pstmt.setDouble(5, booking.getTotalAmount());
            pstmt.setString(6, booking.getStatus());
            pstmt.executeUpdate();

            // Update room status
            updateRoomStatus(booking.getRoomId(), "Occupied");
        }
    }

    public List<Booking> getAllBookings() throws SQLException {
        List<Booking> bookings = new ArrayList<>();
        String sql = "SELECT b.*, g.name as guest_name, r.room_number " +
                     "FROM bookings b " +
                     "JOIN guests g ON b.guest_id = g.id " +
                     "JOIN rooms r ON b.room_id = r.id";
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                bookings.add(mapResultSetToBooking(rs));
            }
        }
        return bookings;
    }

    public void updateBooking(Booking booking) throws SQLException {
        String sql = "UPDATE bookings SET guest_id = ?, room_id = ?, check_in_date = ?, check_out_date = ?, total_amount = ?, status = ? WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, booking.getGuestId());
            pstmt.setInt(2, booking.getRoomId());
            pstmt.setString(3, booking.getCheckInDate().toString());
            pstmt.setString(4, booking.getCheckOutDate().toString());
            pstmt.setDouble(5, booking.getTotalAmount());
            pstmt.setString(6, booking.getStatus());
            pstmt.setInt(7, booking.getId());
            pstmt.executeUpdate();

            if ("Checked-Out".equals(booking.getStatus()) || "Cancelled".equals(booking.getStatus())) {
                updateRoomStatus(booking.getRoomId(), "Available");
            }
        }
    }

    public void deleteBooking(int id) throws SQLException {
        String sql = "DELETE FROM bookings WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }

    public double[] getRevenueForLast7Days() throws SQLException {
        double[] revenue = new double[7];
        String sql = "SELECT check_in_date, SUM(total_amount) as total FROM bookings " +
                     "WHERE check_in_date >= ? GROUP BY check_in_date ORDER BY check_in_date DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, LocalDate.now().minusDays(6).toString());
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    LocalDate date = LocalDate.parse(rs.getString("check_in_date"));
                    int daysAgo = (int) java.time.temporal.ChronoUnit.DAYS.between(date, LocalDate.now());
                    if (daysAgo >= 0 && daysAgo < 7) {
                        revenue[6 - daysAgo] = rs.getDouble("total");
                    }
                }
            }
        }
        return revenue;
    }

    private void updateRoomStatus(int roomId, String status) throws SQLException {
        String sql = "UPDATE rooms SET status = ? WHERE id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, status);
            pstmt.setInt(2, roomId);
            pstmt.executeUpdate();
        }
    }

    private Booking mapResultSetToBooking(ResultSet rs) throws SQLException {
        Booking booking = new Booking();
        booking.setId(rs.getInt("id"));
        booking.setGuestId(rs.getInt("guest_id"));
        booking.setRoomId(rs.getInt("room_id"));
        booking.setCheckInDate(LocalDate.parse(rs.getString("check_in_date")));
        booking.setCheckOutDate(LocalDate.parse(rs.getString("check_out_date")));
        booking.setTotalAmount(rs.getDouble("total_amount"));
        booking.setStatus(rs.getString("status"));
        booking.setGuestName(rs.getString("guest_name"));
        booking.setRoomNumber(rs.getString("room_number"));
        return booking;
    }
}
