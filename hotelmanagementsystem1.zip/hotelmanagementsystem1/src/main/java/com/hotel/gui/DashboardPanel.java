package com.hotel.gui;

import com.hotel.dao.BookingDAO;
import com.hotel.dao.GuestDAO;
import com.hotel.dao.RoomDAO;
import com.hotel.dao.UserDAO;
import com.hotel.model.Room;
import com.hotel.model.User;
import com.hotel.util.StyleUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class DashboardPanel extends JPanel {
    private GuestDAO guestDAO = new GuestDAO();
    private RoomDAO roomDAO = new RoomDAO();
    private BookingDAO bookingDAO = new BookingDAO();
    private UserDAO userDAO = new UserDAO();
    private User currentUser;
    private DefaultListModel<String> feedbackModel = new DefaultListModel<>();

    private JLabel guestCountLabel = new JLabel("0");
    private JLabel roomCountLabel = new JLabel("0");
    private JLabel bookingCountLabel = new JLabel("0");
    private JLabel occupancyLabel = new JLabel("0%");
    private double[] revenueData = new double[7];

    private Color primaryColor = new Color(0, 100, 0); // Ethiopia Green
    private Color accentColor = new Color(255, 205, 0); // Ethiopia Gold
    private Color backgroundColor = new Color(245, 245, 250);

    public DashboardPanel(String titleStr, User user) {
        this.currentUser = user;
        setLayout(new BorderLayout());
        setBackground(backgroundColor);
        
        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(new EmptyBorder(20, 30, 20, 30));
        
        JLabel title = new JLabel(titleStr);
        title.setFont(new Font("Segoe UI", Font.BOLD, 28));
        title.setForeground(primaryColor);
        header.add(title, BorderLayout.WEST);

        JButton refreshBtn = new JButton("🔄 Refresh Data");
        refreshBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        refreshBtn.setBackground(primaryColor);
        refreshBtn.setForeground(Color.WHITE);
        refreshBtn.addActionListener(e -> refreshStats());
        header.add(refreshBtn, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);

        // Content
        JPanel mainContent = new JPanel(new BorderLayout(20, 20));
        mainContent.setOpaque(false);
        mainContent.setBorder(new EmptyBorder(30, 30, 30, 30));

        // Stats Cards Row
        JPanel statsRow = new JPanel(new GridLayout(1, 4, 20, 0));
        statsRow.setOpaque(false);

        statsRow.add(createModernCard("Total Guests", guestCountLabel, "👤", new Color(46, 204, 113)));
        statsRow.add(createModernCard("Total Rooms", roomCountLabel, "🛏", new Color(52, 152, 219)));
        statsRow.add(createModernCard("Bookings", bookingCountLabel, "📅", new Color(241, 196, 15)));
        statsRow.add(createModernCard("Occupancy", occupancyLabel, "📊", new Color(231, 76, 60)));

        mainContent.add(statsRow, BorderLayout.NORTH);

        // Activity and Chart Area
        JPanel lowerArea = new JPanel(new GridLayout(1, 3, 20, 0));
        lowerArea.setOpaque(false);

        // Revenue Chart Panel
        lowerArea.add(createSectionPanel("Revenue Trends (Last 7 Days)", new RevenueChartMock()));
        
        // Quick Actions
        JPanel actions = new JPanel(new GridLayout(2, 2, 15, 15));
        actions.setOpaque(false);
        
        JButton addGuestBtn = createActionButton("Quick Add Guest", "👤");
        addGuestBtn.addActionListener(e -> showQuickGuestDialog());
        actions.add(addGuestBtn);

        JButton addBookingBtn = createActionButton("New Booking", "📅");
        addBookingBtn.addActionListener(e -> showQuickBookingDialog());
        actions.add(addBookingBtn);

        JButton checkOutBtn = createActionButton("Check-Out", "🚪");
        checkOutBtn.addActionListener(e -> showQuickCheckOutDialog());
        actions.add(checkOutBtn);

        JButton maintenanceBtn = createActionButton("Maintenance", "🛠");
        maintenanceBtn.addActionListener(e -> showQuickMaintenanceDialog());
        actions.add(maintenanceBtn);
        
        lowerArea.add(createSectionPanel("Operations Center", actions));

        // Recent Comments / Feedback
        JList<String> feedbackList = new JList<>(feedbackModel);
        feedbackList.setCellRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                label.setBorder(new EmptyBorder(10, 10, 10, 10));
                label.setBackground(index % 2 == 0 ? Color.WHITE : new Color(245, 245, 245));
                return label;
            }
        });
        lowerArea.add(createSectionPanel("Live Feedback & Orders", new JScrollPane(feedbackList)));


        mainContent.add(lowerArea, BorderLayout.CENTER);
        add(mainContent, BorderLayout.CENTER);
        refreshStats();
    }

    private JPanel createModernCard(String title, JLabel valueLabel, String icon, Color accent) {
        JPanel card = new JPanel(new BorderLayout(10, 10));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230), 1),
            new EmptyBorder(20, 20, 20, 20)
        ));

        JLabel iconLabel = new JLabel(icon);
        iconLabel.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 40));
        iconLabel.setForeground(accent);
        
        JPanel textPanel = new JPanel(new GridLayout(2, 1));
        textPanel.setOpaque(false);
        
        JLabel tLabel = new JLabel(title);
        tLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tLabel.setForeground(Color.GRAY);
        
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 30));
        valueLabel.setForeground(new Color(50, 50, 50));
        
        textPanel.add(tLabel);
        textPanel.add(valueLabel);

        card.add(iconLabel, BorderLayout.WEST);
        card.add(textPanel, BorderLayout.CENTER);

        return card;
    }



    private void showQuickGuestDialog() {
        JTextField nameField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField phoneField = new JTextField();
        
        JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));
        panel.add(new JLabel("Full Name:")); panel.add(nameField);
        panel.add(new JLabel("Email:")); panel.add(emailField);
        panel.add(new JLabel("Phone:")); panel.add(phoneField);
        
        if (JOptionPane.showConfirmDialog(this, panel, "Quick Guest Registration", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            try {
                com.hotel.model.Guest g = new com.hotel.model.Guest(0, nameField.getText(), emailField.getText(), phoneField.getText(), "");
                guestDAO.addGuest(g);
                JOptionPane.showMessageDialog(this, "Guest registered successfully!");
                refreshStats();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        }
    }

    private void showQuickCheckOutDialog() {
        try {
            List<com.hotel.model.Booking> bookings = bookingDAO.getAllBookings().stream()
                    .filter(b -> "Confirmed".equals(b.getStatus()) || "Active".equals(b.getStatus())).toList();
            
            if (bookings.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No active bookings found for check-out.");
                return;
            }
            
            JComboBox<com.hotel.model.Booking> bookingBox = new JComboBox<>(new java.util.Vector<>(bookings));
            
            JPanel panel = new JPanel(new GridLayout(2, 1, 5, 5));
            panel.add(new JLabel("Select Booking to Check-Out:"));
            panel.add(bookingBox);
            
            if (JOptionPane.showConfirmDialog(this, panel, "Guest Check-Out", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                com.hotel.model.Booking b = (com.hotel.model.Booking) bookingBox.getSelectedItem();
                b.setStatus("Checked-Out");
                bookingDAO.updateBooking(b);
                JOptionPane.showMessageDialog(this, "Guest checked out successfully! Room " + b.getRoomNumber() + " is now Available.");
                refreshStats();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void showQuickBookingDialog() {
        try {
            List<com.hotel.model.Guest> guests = guestDAO.getAllGuests();
            List<com.hotel.model.Room> rooms = roomDAO.getAllRooms().stream()
                    .filter(r -> "Available".equals(r.getStatus())).toList();

            if (guests.isEmpty() || rooms.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Need at least one guest and one available room.");
                return;
            }

            JComboBox<com.hotel.model.Guest> guestBox = new JComboBox<>(new java.util.Vector<>(guests));
            JComboBox<com.hotel.model.Room> roomBox = new JComboBox<>(new java.util.Vector<>(rooms));
            JTextField checkInField = new JTextField(java.time.LocalDate.now().toString());
            JTextField checkOutField = new JTextField(java.time.LocalDate.now().plusDays(1).toString());

            JPanel panel = new JPanel(new GridLayout(4, 2, 5, 5));
            panel.add(new JLabel("Guest:")); panel.add(guestBox);
            panel.add(new JLabel("Room:")); panel.add(roomBox);
            panel.add(new JLabel("Check-In:")); panel.add(checkInField);
            panel.add(new JLabel("Check-Out:")); panel.add(checkOutField);

            if (JOptionPane.showConfirmDialog(this, panel, "Quick Booking", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                com.hotel.model.Guest guest = (com.hotel.model.Guest) guestBox.getSelectedItem();
                com.hotel.model.Room room = (com.hotel.model.Room) roomBox.getSelectedItem();
                java.time.LocalDate in = java.time.LocalDate.parse(checkInField.getText());
                java.time.LocalDate out = java.time.LocalDate.parse(checkOutField.getText());

                long days = java.time.temporal.ChronoUnit.DAYS.between(in, out);
                if (days <= 0) days = 1;
                double amount = days * room.getPrice();

                com.hotel.model.Booking b = new com.hotel.model.Booking(0, guest.getId(), room.getId(), in, out, amount, "Confirmed", null, null);
                bookingDAO.addBooking(b);
                JOptionPane.showMessageDialog(this, "Booking Successful!");
                refreshStats();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void showQuickMaintenanceDialog() {
        try {
            List<com.hotel.model.Room> rooms = roomDAO.getAllRooms();
            JComboBox<com.hotel.model.Room> roomBox = new JComboBox<>(new java.util.Vector<>(rooms));
            
            JPanel panel = new JPanel(new GridLayout(2, 1, 5, 5));
            panel.add(new JLabel("Select Room to Toggle Maintenance:"));
            panel.add(roomBox);

            if (JOptionPane.showConfirmDialog(this, panel, "Room Maintenance", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                com.hotel.model.Room room = (com.hotel.model.Room) roomBox.getSelectedItem();
                if ("Maintenance".equals(room.getStatus())) {
                    room.setStatus("Available");
                } else {
                    room.setStatus("Maintenance");
                }
                roomDAO.updateRoom(room);
                JOptionPane.showMessageDialog(this, "Room status updated to: " + room.getStatus());
                refreshStats();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private JPanel createSectionPanel(String title, JComponent content) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        
        JLabel tLabel = new JLabel(title);
        tLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        tLabel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(230, 230, 230)));
        
        panel.add(tLabel, BorderLayout.NORTH);
        panel.add(content, BorderLayout.CENTER);
        
        return panel;
    }

    private JButton createActionButton(String text, String icon) {
        JButton btn = new JButton(icon + "   " + text);
        StyleUtils.applySecondaryStyle(btn);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setPreferredSize(new Dimension(0, 50));
        return btn;
    }

    public void refreshStats() {
        try {
            int guestCount = guestDAO.getAllGuests().size();
            List<Room> rooms = roomDAO.getAllRooms();
            int roomCount = rooms.size();
            int bookingCount = bookingDAO.getAllBookings().size();
            
            long occupiedCount = rooms.stream().filter(r -> "Occupied".equals(r.getStatus())).count();
            double occupancy = roomCount > 0 ? (double) occupiedCount / roomCount * 100 : 0;

            guestCountLabel.setText(String.valueOf(guestCount));
            roomCountLabel.setText(String.valueOf(roomCount));
            bookingCountLabel.setText(String.valueOf(bookingCount));
            occupancyLabel.setText(String.format("%.1f%%", occupancy));
            
            revenueData = bookingDAO.getRevenueForLast7Days();
            
            // Refresh Feedback
            feedbackModel.clear();
            List<String> notes = userDAO.getNotifications(currentUser.getId());
            if (notes.isEmpty()) {
                feedbackModel.addElement("No recent feedback or orders.");
            } else {
                for (String note : notes) {
                    // Split multiline feedback for list display or just replace newlines
                    feedbackModel.addElement("<html>" + note.replace("\n", "<br>") + "</html>");
                }
            }
            
            repaint();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Mock Chart Class
    class RevenueChartMock extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            int w = getWidth();
            int h = getHeight();
            int padding = 40;
            
            g2.setColor(new Color(240, 240, 240));
            g2.drawLine(padding, h - padding, w - padding, h - padding);
            
            double maxVal = 0;
            for (double d : revenueData) maxVal = Math.max(maxVal, d);
            if (maxVal == 0) maxVal = 1000; // Default scale
            
            int barWidth = (w - 2 * padding) / revenueData.length - 10;
            
            for (int i = 0; i < revenueData.length; i++) {
                int barHeight = (int) ((h - 2 * padding) * (revenueData[i] / maxVal));
                g2.setColor(primaryColor);
                g2.fillRect(padding + i * (barWidth + 10), h - padding - barHeight, barWidth, barHeight);
                g2.setColor(accentColor);
                g2.drawRect(padding + i * (barWidth + 10), h - padding - barHeight, barWidth, barHeight);
                
                // Show value on top of bar
                if (revenueData[i] > 0) {
                    g2.setColor(Color.BLACK);
                    g2.setFont(new Font("Segoe UI", Font.BOLD, 10));
                    g2.drawString(String.format("%.0f", revenueData[i]), padding + i * (barWidth + 10), h - padding - barHeight - 5);
                }
            }
        }
    }

}
