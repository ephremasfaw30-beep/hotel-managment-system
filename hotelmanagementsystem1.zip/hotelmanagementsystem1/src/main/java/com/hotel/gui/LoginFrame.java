package com.hotel.gui;

import com.formdev.flatlaf.FlatLightLaf;
import com.hotel.dao.UserDAO;
import com.hotel.model.User;
import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    private JTextField userField;
    private JPasswordField passField;
    private UserDAO userDAO = new UserDAO();

    public LoginFrame() {
        setTitle("Ethiopia Hotel - Secure Portal");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1200, 750);
        setLocationRelativeTo(null);
        setUndecorated(true); // Modern frameless look

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 205, 0), 2)); // Gold border for the whole frame
        setContentPane(mainPanel);

        // --- Left Side: Image Panel ---
        JPanel leftPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    ImageIcon icon = new ImageIcon(getClass().getResource("/images/hotel_bg.jpg"));
                    Image img = icon.getImage();
                    
                    // Maintain aspect ratio while filling
                    double imgRatio = (double) img.getWidth(null) / img.getHeight(null);
                    double panelRatio = (double) getWidth() / getHeight();
                    
                    int drawW, drawH;
                    if (panelRatio > imgRatio) {
                        drawW = getWidth();
                        drawH = (int) (getWidth() / imgRatio);
                    } else {
                        drawW = (int) (getHeight() * imgRatio);
                        drawH = getHeight();
                    }
                    
                    g.drawImage(img, (getWidth() - drawW) / 2, (getHeight() - drawH) / 2, drawW, drawH, this);
                    
                    // Gradient Overlay
                    Graphics2D g2 = (Graphics2D) g;
                    GradientPaint gp = new GradientPaint(0, 0, new Color(0, 80, 0, 50), getWidth(), 0, new Color(0, 40, 0, 150));
                    g2.setPaint(gp);
                    g2.fillRect(0, 0, getWidth(), getHeight());

                } catch (Exception e) {
                    g.setColor(new Color(0, 60, 0));
                    g.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        leftPanel.setPreferredSize(new Dimension(600, 0));
        leftPanel.setLayout(new BorderLayout());
        
        // Branding on Image
        JPanel branding = new JPanel(new BorderLayout());
        branding.setOpaque(false);
        branding.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        
        JLabel welcome = new JLabel("<html>Experience<br><b style='font-size:30pt;'>LUXURY</b><br>at Ethiopia Hotel</html>");
        welcome.setFont(new Font("Serif", Font.PLAIN, 24));
        welcome.setForeground(Color.WHITE);
        branding.add(welcome, BorderLayout.NORTH);
        
        leftPanel.add(branding, BorderLayout.CENTER);
        mainPanel.add(leftPanel, BorderLayout.WEST);

        // --- Right Side: Form Panel ---
        JPanel rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setBackground(new Color(20, 25, 20)); // Deep Dark Green/Black
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 40, 10, 40);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;

        // Close Button
        JPanel topActions = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        topActions.setOpaque(false);
        JButton closeBtn = new JButton("✕");
        closeBtn.setFont(new Font("Arial", Font.BOLD, 18));
        closeBtn.setForeground(Color.GRAY);
        closeBtn.setBorderPainted(false);
        closeBtn.setContentAreaFilled(false);
        closeBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        closeBtn.addActionListener(e -> System.exit(0));
        topActions.add(closeBtn);
        
        gbc.gridy = 0; gbc.weightx = 1;
        gbc.anchor = GridBagConstraints.NORTHEAST;
        rightPanel.add(topActions, gbc);

        // Form Title
        gbc.gridy = 1; gbc.anchor = GridBagConstraints.CENTER; gbc.insets = new Insets(0, 50, 30, 50);
        JLabel titleLabel = new JLabel("Portal Login");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        titleLabel.setForeground(new Color(255, 205, 0));
        rightPanel.add(titleLabel, gbc);

        // Username
        gbc.gridy = 2; gbc.insets = new Insets(10, 50, 0, 50);
        JLabel uLabel = new JLabel("USERNAME");
        uLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        uLabel.setForeground(new Color(0, 180, 0));
        rightPanel.add(uLabel, gbc);

        gbc.gridy = 3; gbc.insets = new Insets(5, 50, 20, 50);
        userField = new JTextField();
        userField.setPreferredSize(new Dimension(300, 45));
        userField.setBackground(new Color(255, 255, 255, 20));
        userField.setForeground(Color.WHITE);
        userField.setCaretColor(Color.WHITE);
        userField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(255, 255, 255, 40)),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)));
        rightPanel.add(userField, gbc);

        // Password
        gbc.gridy = 4; gbc.insets = new Insets(10, 50, 0, 50);
        JLabel pLabel = new JLabel("PASSWORD");
        pLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        pLabel.setForeground(new Color(0, 180, 0));
        rightPanel.add(pLabel, gbc);

        gbc.gridy = 5; gbc.insets = new Insets(5, 50, 30, 50);
        passField = new JPasswordField();
        passField.setPreferredSize(new Dimension(300, 45));
        passField.setBackground(new Color(255, 255, 255, 20));
        passField.setForeground(Color.WHITE);
        passField.setCaretColor(Color.WHITE);
        passField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(255, 255, 255, 40)),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)));
        rightPanel.add(passField, gbc);

        // Buttons Panel
        JPanel btnPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        btnPanel.setOpaque(false);

        JButton loginBtn = new JButton("SIGN IN");
        loginBtn.setPreferredSize(new Dimension(0, 50));
        loginBtn.setBackground(new Color(0, 120, 0));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        loginBtn.setFocusPainted(false);
        loginBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginBtn.addActionListener(e -> handleLogin());

        JButton exitBtn = new JButton("LOGOUT/EXIT");
        exitBtn.setPreferredSize(new Dimension(0, 50));
        exitBtn.setBackground(new Color(150, 0, 0));
        exitBtn.setForeground(Color.WHITE);
        exitBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        exitBtn.setFocusPainted(false);
        exitBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        exitBtn.addActionListener(e -> System.exit(0));

        btnPanel.add(loginBtn);
        btnPanel.add(exitBtn);

        gbc.gridy = 6; gbc.insets = new Insets(10, 50, 15, 50);
        rightPanel.add(btnPanel, gbc);

        // Register
        gbc.gridy = 7;
        JButton regBtn = new JButton("Create an Account");

        regBtn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        regBtn.setForeground(new Color(255, 205, 0));
        regBtn.setContentAreaFilled(false);
        regBtn.setBorderPainted(false);
        regBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        regBtn.addActionListener(e -> showRegisterDialog());
        rightPanel.add(regBtn, gbc);

        mainPanel.add(rightPanel, BorderLayout.CENTER);

        ensureDefaultUser();
    }



    private void handleLogin() {
        String username = userField.getText().trim();
        String password = new String(passField.getPassword()); // Do NOT trim passwords

        try {
            User user = userDAO.authenticate(username, password);
            if (user != null) {
                JOptionPane.showMessageDialog(this, "Login Successful! Role: " + user.getRole());
                new MainFrame(user).setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
        }
    }

    private void showRegisterDialog() {
        JTextField fnField = new JTextField();
        JTextField uField = new JTextField();
        JTextField eField = new JTextField();
        JPasswordField pField = new JPasswordField();
        JPasswordField cpField = new JPasswordField();
        JTextField phField = new JTextField();
        JComboBox<String> rBox = new JComboBox<>(new String[]{"Customer"});
        rBox.setEnabled(false); // Only Customers can self-register

        JPanel panel = new JPanel(new GridLayout(7, 2, 10, 10));
        panel.add(new JLabel("Full Name:")); panel.add(fnField);
        panel.add(new JLabel("Username:")); panel.add(uField);
        panel.add(new JLabel("Email:")); panel.add(eField);
        panel.add(new JLabel("Password:")); panel.add(pField);
        panel.add(new JLabel("Confirm Password:")); panel.add(cpField);
        panel.add(new JLabel("Phone:")); panel.add(phField);
        panel.add(new JLabel("Account Type:")); panel.add(rBox);

        int result = JOptionPane.showConfirmDialog(this, panel, "New Customer Registration", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String fullName = fnField.getText().trim();
            String username = uField.getText().trim();
            String email = eField.getText().trim();
            String pass = new String(pField.getPassword());
            String confirmPass = new String(cpField.getPassword());
            String phone = phField.getText().trim();
            String role = (String) rBox.getSelectedItem();

            if (fullName.isEmpty() || username.isEmpty() || email.isEmpty() || pass.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all mandatory fields.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Email Validation (name@gmail.com)
            if (!email.toLowerCase().endsWith("@gmail.com") || email.length() < 11) {
                JOptionPane.showMessageDialog(this, "Invalid Email. Please use a valid Gmail address (e.g., name@gmail.com).", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Phone Validation (09 + 8 digits = 10 total)
            if (!phone.matches("^09\\d{8}$")) {
                JOptionPane.showMessageDialog(this, "Invalid Phone Number. It must start with '09' and contain exactly 10 digits (e.g., 0912345678).", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!pass.equals(confirmPass)) {
                JOptionPane.showMessageDialog(this, "Passwords do not match!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                if (userDAO.existsByUsername(username)) {
                    JOptionPane.showMessageDialog(this, "Username '" + username + "' is already taken. Please choose another.", "Registration Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                User newUser = new User(0, fullName, username, email, pass, phone, role);
                userDAO.addUser(newUser);
                JOptionPane.showMessageDialog(this, "Registration Successful! Welcome, " + fullName + "\nYou can now sign in.");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Registration failed: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }


    private void ensureDefaultUser() {
        try {
            if (!userDAO.existsByUsername("ephrem")) {
                userDAO.addUser(new User(0, "Ephrem Abrham", "ephrem", "ephrem@hotel.com", "abrham", "0911223344", "Admin"));
            }
        } catch (Exception e) {
            System.err.println("Default user check skipped: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        FlatLightLaf.setup();
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
