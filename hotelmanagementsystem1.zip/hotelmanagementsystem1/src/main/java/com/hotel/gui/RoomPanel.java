package com.hotel.gui;

import com.hotel.dao.RoomDAO;
import com.hotel.model.Room;
import com.hotel.util.StyleUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class RoomPanel extends JPanel {
    private RoomDAO roomDAO = new RoomDAO();
    private JTable roomTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;

    public RoomPanel() {
        this("Admin"); // Default for safety
    }

    public RoomPanel(String role) {
        setLayout(new BorderLayout());

        // Top Bar
        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topBar.setBackground(Color.WHITE);
        topBar.setBorder(new javax.swing.border.EmptyBorder(15, 20, 15, 20));

        searchField = new JTextField(15);
        searchField.setPreferredSize(new Dimension(150, 35));

        JButton searchBtn = new JButton("🔍 Search");
        JButton refreshBtn = new JButton("🔄 Refresh");
        JButton addBtn = new JButton("➕ Add Room");
        JButton updateBtn = new JButton("📝 Update Selected");
        JButton deleteBtn = new JButton("🗑 Delete Selected");

        StyleUtils.applyPrimaryStyle(searchBtn);
        StyleUtils.applyPrimaryStyle(refreshBtn);
        StyleUtils.applyPrimaryStyle(addBtn);
        StyleUtils.applyPrimaryStyle(updateBtn);
        StyleUtils.applyDangerStyle(deleteBtn);

        topBar.add(new JLabel("Search: "));
        topBar.add(searchField);
        topBar.add(searchBtn);
        topBar.add(Box.createHorizontalStrut(10));
        topBar.add(refreshBtn);
        topBar.add(Box.createHorizontalGlue());
        
        if (!"Customer".equals(role)) {
            topBar.add(addBtn);
            topBar.add(updateBtn);
            topBar.add(deleteBtn);
        }

        add(topBar, BorderLayout.NORTH);
        
        // Table
        tableModel = new DefaultTableModel(new String[]{"ID", "Room #", "Type", "Price", "Status", "Description"}, 0);
        roomTable = new JTable(tableModel);
        add(new JScrollPane(roomTable), BorderLayout.CENTER);

        // Events
        searchBtn.addActionListener(e -> performSearch());
        refreshBtn.addActionListener(e -> loadData());
        
        if (!"Customer".equals(role)) {
            addBtn.addActionListener(e -> showRoomDialog(null));
            updateBtn.addActionListener(e -> {
                int row = roomTable.getSelectedRow();
                if (row != -1) {
                    int id = (int) tableModel.getValueAt(row, 0);
                    showRoomDialog(id);
                }
            });
            deleteBtn.addActionListener(e -> {
                int row = roomTable.getSelectedRow();
                if (row != -1) {
                    int id = (int) tableModel.getValueAt(row, 0);
                    if (JOptionPane.showConfirmDialog(this, "Delete room?") == JOptionPane.YES_OPTION) {
                        try {
                            roomDAO.deleteRoom(id);
                            loadData();
                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
                        }
                    }
                }
            });
        }

        loadData();
    }


    private void loadData() {
        try {
            updateTable(roomDAO.getAllRooms());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void performSearch() {
        try {
            updateTable(roomDAO.searchRooms(searchField.getText()));
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void updateTable(List<Room> rooms) {
        tableModel.setRowCount(0);
        for (Room r : rooms) {
            tableModel.addRow(new Object[]{r.getId(), r.getRoomNumber(), r.getType(), r.getPrice(), r.getStatus(), r.getDescription()});
        }
    }

    private void showRoomDialog(Integer roomId) {
        Room room = null;
        if (roomId != null) {
            try {
                List<Room> res = roomDAO.searchRooms(""); // Generic search, find by ID logic could be better
                room = res.stream().filter(r -> r.getId() == roomId).findFirst().orElse(null);
            } catch (SQLException e) {}
        }

        JTextField numField = new JTextField(room != null ? room.getRoomNumber() : "");
        JComboBox<String> typeBox = new JComboBox<>(new String[]{"Single", "Double", "Suite", "Deluxe"});
        if (room != null) typeBox.setSelectedItem(room.getType());
        
        JTextField priceField = new JTextField(room != null ? String.valueOf(room.getPrice()) : "0.0");
        JComboBox<String> statusBox = new JComboBox<>(new String[]{"Available", "Occupied", "Maintenance"});
        if (room != null) statusBox.setSelectedItem(room.getStatus());

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("Room Number:")); panel.add(numField);
        panel.add(new JLabel("Type:")); panel.add(typeBox);
        panel.add(new JLabel("Price:")); panel.add(priceField);
        panel.add(new JLabel("Status:")); panel.add(statusBox);

        if (JOptionPane.showConfirmDialog(null, panel, roomId == null ? "Add Room" : "Update Room", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            try {
                Room r = new Room(roomId != null ? roomId : 0, numField.getText(), 
                        (String) typeBox.getSelectedItem(), Double.parseDouble(priceField.getText()), 
                        (String) statusBox.getSelectedItem(), "");
                if (roomId == null) roomDAO.addRoom(r);
                else roomDAO.updateRoom(r);
                loadData();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        }
    }
}
