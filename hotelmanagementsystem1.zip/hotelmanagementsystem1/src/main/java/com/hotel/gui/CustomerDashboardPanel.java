package com.hotel.gui;

import com.hotel.model.User;
import com.hotel.dao.BookingDAO;
import com.hotel.dao.GuestDAO;
import com.hotel.dao.RoomDAO;
import com.hotel.dao.UserDAO;
import com.hotel.model.Booking;
import com.hotel.model.Guest;
import com.hotel.model.Room;
import com.hotel.util.StyleUtils;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class CustomerDashboardPanel extends JPanel {
    private BookingDAO bookingDAO = new BookingDAO();
    private RoomDAO roomDAO = new RoomDAO();
    private UserDAO userDAO = new UserDAO();
    private User currentUser;
    private JLabel walletLabel;

    public CustomerDashboardPanel(MainFrame mainFrame, User user) {
        this.currentUser = user;
        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 250));

        // --- Header ---
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(new EmptyBorder(30, 40, 30, 40));

        JLabel welcome = new JLabel("Welcome Home, " + user.getFullName() + "!");
        welcome.setFont(new Font("Serif", Font.BOLD, 32));
        welcome.setForeground(new Color(0, 100, 0));
        header.add(welcome, BorderLayout.WEST);

        // Wallet Balance in Header
        JPanel walletInfo = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        walletInfo.setOpaque(false);
        JLabel wText = new JLabel("Your Wallet: ");
        wText.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        walletLabel = new JLabel(String.format("%.2f ETB", user.getBalance()));
        walletLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        walletLabel.setForeground(new Color(0, 150, 0));
        walletInfo.add(wText);
        walletInfo.add(walletLabel);
        header.add(walletInfo, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);

        // --- Main Content ---
        JPanel content = new JPanel(new GridBagLayout());
        content.setOpaque(false);
        content.setBorder(new EmptyBorder(30, 40, 40, 40));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 0, 0, 30);
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;

        // --- Left Side: Reserve a Room (New Flow) ---
        JPanel reserveCard = new JPanel(new BorderLayout(0, 20));
        reserveCard.setBackground(Color.WHITE);
        reserveCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230)),
            new EmptyBorder(30, 30, 30, 30)
        ));
        reserveCard.setPreferredSize(new Dimension(550, 500));

        JLabel resTitle = new JLabel("Reserve a Luxury Room");
        resTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        
        // Hero Image
        JLabel heroImg = new JLabel();
        ImageIcon icon = new ImageIcon("C:\\Users\\admin\\.gemini\\antigravity\\brain\\4c726e57-1615-48a2-aeca-1a13680b074d\\hotel_booking_hero_1778919374216.png");
        Image scaled = icon.getImage().getScaledInstance(490, 150, Image.SCALE_SMOOTH);
        heroImg.setIcon(new ImageIcon(scaled));
        heroImg.setBorder(BorderFactory.createLineBorder(new Color(230, 230, 230)));
        
        JPanel titlePanel = new JPanel(new BorderLayout(0, 10));
        titlePanel.setOpaque(false);
        titlePanel.add(resTitle, BorderLayout.NORTH);
        titlePanel.add(heroImg, BorderLayout.CENTER);
        
        reserveCard.add(titlePanel, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(8, 1, 10, 10));
        form.setOpaque(false);

        form.add(new JLabel("1. Guest Name / ID:"));
        JTextField guestField = new JTextField(currentUser.getFullName() + " (ID: " + currentUser.getId() + ")");
        guestField.setEditable(false);
        form.add(guestField);

        form.add(new JLabel("2. Select Room Type:"));
        JComboBox<String> roomTypeBox = new JComboBox<>(new String[]{
            "Single (1000 ETB)", 
            "Double (2000 ETB)", 
            "Suite (3500 ETB)",
            "Deluxe (5000 ETB)",
            "Penthouse (12000 ETB)"
        });
        form.add(roomTypeBox);

        form.add(new JLabel("3. Check-In / Check-Out (YYYY-MM-DD):"));
        JPanel datePanel = new JPanel(new GridLayout(1, 2, 10, 0));
        datePanel.setOpaque(false);
        JTextField inField = new JTextField(java.time.LocalDate.now().toString());
        JTextField outField = new JTextField(java.time.LocalDate.now().plusDays(1).toString());
        datePanel.add(inField);
        datePanel.add(outField);
        form.add(datePanel);

        form.add(new JLabel("4. Select Payment Method:"));
        JComboBox<String> payMethodBox = new JComboBox<>(new String[]{"Abyssinia Bank", "CBE Birr", "Telebirr"});
        form.add(payMethodBox);

        form.add(new JLabel("5. Payment Details (System Defaults):"));
        JLabel detailLabel = new JLabel("Account: Ethiopia Hotel | No: 70215028");
        detailLabel.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        detailLabel.setForeground(Color.GRAY);
        form.add(detailLabel);

        // Update detail label based on selection
        payMethodBox.addActionListener(e -> {
            String method = (String) payMethodBox.getSelectedItem();
            if (method.contains("Abyssinia")) detailLabel.setText("Account: Ethiopia Hotel | No: 70215028");
            else if (method.contains("CBE")) detailLabel.setText("Account: Ethiopia Hotel | No: 1000290231632");
            else detailLabel.setText("Account: Ethiopia Hotel | No: 0918680677");
        });

        reserveCard.add(form, BorderLayout.CENTER);

        JButton bookNowBtn = new JButton("CONFIRM & PAY NOW");
        StyleUtils.applyPrimaryStyle(bookNowBtn);
        bookNowBtn.setPreferredSize(new Dimension(0, 60));
        bookNowBtn.addActionListener(e -> handleQuickBooking(roomTypeBox, payMethodBox, inField, outField));
        reserveCard.add(bookNowBtn, BorderLayout.SOUTH);

        gbc.gridx = 0; gbc.weightx = 0.6;
        content.add(reserveCard, gbc);

        // --- Right Side: Support Card ---
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setOpaque(false);

        // Quick Support
        JPanel supportCard = new JPanel(new BorderLayout(10, 10));
        supportCard.setBackground(Color.WHITE);
        supportCard.setBorder(new EmptyBorder(30, 30, 30, 30));
        JLabel sTitle = new JLabel("Customer Support");
        sTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        supportCard.add(sTitle, BorderLayout.NORTH);
        
        JTextArea sInfo = new JTextArea("Need help with your booking?\nCall us: +251 911 223344\nReception is available 24/7.\n\nEnjoy the most premium experience at Ethiopia Hotel!");
        sInfo.setEditable(false);
        sInfo.setLineWrap(true);
        sInfo.setWrapStyleWord(true);
        sInfo.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        supportCard.add(sInfo, BorderLayout.CENTER);
        
        rightPanel.add(supportCard, BorderLayout.CENTER);

        gbc.gridx = 1; gbc.weightx = 0.4; gbc.insets = new Insets(0, 0, 0, 0);
        content.add(rightPanel, gbc);

        add(content, BorderLayout.CENTER);
    }

    private void handleQuickBooking(JComboBox<String> typeBox, JComboBox<String> payBox, JTextField inField, JTextField outField) {
        String typeInfo = (String) typeBox.getSelectedItem();
        String method = (String) payBox.getSelectedItem();
        String checkIn = inField.getText();
        String checkOut = outField.getText();
        
        final double price;
        final String type;
        if (typeInfo.contains("Double")) { 
            price = 2000.0; type = "Double"; 
        } else if (typeInfo.contains("Suite")) { 
            price = 3500.0; type = "Suite"; 
        } else if (typeInfo.contains("Deluxe")) { 
            price = 5000.0; type = "Deluxe"; 
        } else if (typeInfo.contains("Penthouse")) { 
            price = 12000.0; type = "Penthouse"; 
        } else {
            price = 1000.0; type = "Single";
        }

        final String finalType = type;

        if (currentUser.getBalance() < price) {
            JOptionPane.showMessageDialog(this, "Insufficient Balance! Please top up your wallet.", "Payment Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, 
            "Confirm Booking?\nRoom Type: " + type + "\nPrice: " + price + " ETB\nPayment: " + method,
            "Confirm Payment", JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                // 1. Find an available room of that type
                List<Room> available = roomDAO.getAllRooms().stream()
                        .filter(r -> r.getType().equalsIgnoreCase(finalType) && "Available".equals(r.getStatus()))
                        .toList();
                
                if (available.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Sorry, no " + type + " rooms are currently available.");
                    return;
                }
                
                Room selectedRoom = available.get(0);
                
                // 2. Ensure Guest Exists
                GuestDAO guestDAO = new GuestDAO();
                Guest guest = guestDAO.getGuestByEmail(currentUser.getEmail());
                if (guest == null) {
                    guest = new Guest(0, currentUser.getFullName(), currentUser.getEmail(), currentUser.getPhone(), "Customer");
                    guestDAO.addGuest(guest);
                    // Retrieve again to get the auto-generated ID
                    guest = guestDAO.getGuestByEmail(currentUser.getEmail());
                }

                // 3. Create Booking
                java.time.LocalDate in = java.time.LocalDate.parse(checkIn);
                java.time.LocalDate out = java.time.LocalDate.parse(checkOut);
                
                Booking b = new Booking(0, guest.getId(), selectedRoom.getId(), 
                                        in, out, 
                                        price, "Paid", null, null);
                bookingDAO.addBooking(b);
                
                // 4. Update Wallet
                double newBal = currentUser.getBalance() - price;
                userDAO.updateBalance(currentUser.getId(), newBal);
                currentUser.setBalance(newBal);
                
                // 4. Update UI
                walletLabel.setText(String.format("%.2f ETB", newBal));
                JOptionPane.showMessageDialog(this, "Success! Your room is reserved.\nRoom Number: " + selectedRoom.getRoomNumber() + "\nStatus: Paid", "Booking Confirmed", JOptionPane.INFORMATION_MESSAGE);
                
                // Refresh the panel (optional)
                this.revalidate();
                this.repaint();
                
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        }
    }
}
