package com.hotel.gui;

import com.hotel.dao.GuestDAO;
import com.hotel.model.Guest;
import com.hotel.util.StyleUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class GuestPanel extends JPanel {
    private GuestDAO guestDAO = new GuestDAO();
    private JTable guestTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;

    public GuestPanel() {
        setLayout(new BorderLayout());

        // Top Bar: Search and Actions
        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topBar.setBackground(Color.WHITE);
        topBar.setBorder(new javax.swing.border.EmptyBorder(15, 20, 15, 20));
        
        searchField = new JTextField(20);
        searchField.setPreferredSize(new Dimension(200, 35));
        
        JButton searchBtn = new JButton("🔍 Search");
        JButton refreshBtn = new JButton("🔄 Refresh");
        JButton addBtn = new JButton("➕ Add Guest");
        JButton updateBtn = new JButton("📝 Update Selected");
        JButton deleteBtn = new JButton("🗑 Delete Selected");

        StyleUtils.applySecondaryStyle(searchBtn);
        StyleUtils.applySecondaryStyle(refreshBtn);
        StyleUtils.applyPrimaryStyle(addBtn);
        StyleUtils.applyPrimaryStyle(updateBtn);
        StyleUtils.applyDangerStyle(deleteBtn);

        topBar.add(new JLabel("Search: "));
        topBar.add(searchField);
        topBar.add(searchBtn);
        topBar.add(Box.createHorizontalStrut(10));
        topBar.add(refreshBtn);
        topBar.add(Box.createHorizontalGlue());
        topBar.add(addBtn);
        topBar.add(updateBtn);
        topBar.add(deleteBtn);

        add(topBar, BorderLayout.NORTH);

        // Table
        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Email", "Phone", "Address"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        guestTable = new JTable(tableModel);
        add(new JScrollPane(guestTable), BorderLayout.CENTER);

        // Event Listeners
        searchBtn.addActionListener(e -> performSearch());
        refreshBtn.addActionListener(e -> loadData());
        addBtn.addActionListener(e -> showGuestDialog(null));
        updateBtn.addActionListener(e -> {
            int row = guestTable.getSelectedRow();
            if (row != -1) {
                int id = (int) tableModel.getValueAt(row, 0);
                showGuestDialog(id);
            } else {
                JOptionPane.showMessageDialog(this, "Select a guest to update.");
            }
        });
        deleteBtn.addActionListener(e -> {
            int row = guestTable.getSelectedRow();
            if (row != -1) {
                int id = (int) tableModel.getValueAt(row, 0);
                int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this guest?", "Confirm", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    try {
                        guestDAO.deleteGuest(id);
                        loadData();
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(this, "Error deleting guest: " + ex.getMessage());
                    }
                }
            }
        });

        loadData();
    }

    private void loadData() {
        try {
            List<Guest> guests = guestDAO.getAllGuests();
            updateTable(guests);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading guests: " + e.getMessage());
        }
    }

    private void performSearch() {
        try {
            String query = searchField.getText();
            List<Guest> guests = guestDAO.searchGuests(query);
            updateTable(guests);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error searching guests: " + e.getMessage());
        }
    }

    private void updateTable(List<Guest> guests) {
        tableModel.setRowCount(0);
        for (Guest g : guests) {
            tableModel.addRow(new Object[]{g.getId(), g.getName(), g.getEmail(), g.getPhone(), g.getAddress()});
        }
    }

    private void showGuestDialog(Integer guestId) {
        Guest guest = null;
        if (guestId != null) {
            try {
                // For simplicity, we search by ID
                List<Guest> result = guestDAO.searchGuests(String.valueOf(guestId));
                if (!result.isEmpty()) guest = result.get(0);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        JTextField nameField = new JTextField(guest != null ? guest.getName() : "");
        JTextField emailField = new JTextField(guest != null ? guest.getEmail() : "");
        JTextField phoneField = new JTextField(guest != null ? guest.getPhone() : "");
        JTextField addressField = new JTextField(guest != null ? guest.getAddress() : "");

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("Name:")); panel.add(nameField);
        panel.add(new JLabel("Email:")); panel.add(emailField);
        panel.add(new JLabel("Phone:")); panel.add(phoneField);
        panel.add(new JLabel("Address:")); panel.add(addressField);

        int result = JOptionPane.showConfirmDialog(null, panel, 
                guestId == null ? "Add Guest" : "Update Guest", JOptionPane.OK_CANCEL_OPTION);
        
        if (result == JOptionPane.OK_OPTION) {
            // Validation
            if (nameField.getText().trim().isEmpty() || phoneField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Name and Phone are required.");
                return;
            }

            Guest g = new Guest(guestId != null ? guestId : 0, 
                    nameField.getText(), emailField.getText(), phoneField.getText(), addressField.getText());
            try {
                if (guestId == null) {
                    guestDAO.addGuest(g);
                } else {
                    guestDAO.updateGuest(g);
                }
                loadData();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error saving guest: " + ex.getMessage());
            }
        }
    }
}
