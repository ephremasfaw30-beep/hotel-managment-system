package com.hotel.gui;

import com.hotel.model.User;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class MainFrame extends JFrame {
    private JPanel contentPanel;
    private CardLayout cardLayout;
    private JPanel sidebar;

    private Color sidebarColor = new Color(0, 80, 0); // Ethiopia Green
    private Color accentColor = new Color(255, 205, 0); // Ethiopia Gold
    private Color hoverColor = new Color(0, 100, 0);

    public MainFrame(User user) {
        setTitle("Ethiopia Hotel Management System - Pro");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1300, 850);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // --- Sidebar ---
        sidebar = new JPanel();
        sidebar.setBackground(sidebarColor);
        sidebar.setPreferredSize(new Dimension(250, 0));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBorder(new EmptyBorder(20, 0, 20, 0));

        // Sidebar Branding
        JLabel brandLogo = new JLabel("ETHIOPIA HOTEL");
        brandLogo.setFont(new Font("Serif", Font.BOLD, 22));
        brandLogo.setForeground(accentColor);
        brandLogo.setAlignmentX(Component.CENTER_ALIGNMENT);
        brandLogo.setBorder(new EmptyBorder(0, 0, 30, 0));
        sidebar.add(brandLogo);

        // Sidebar Items
        contentPanel = new JPanel();
        cardLayout = new CardLayout();
        contentPanel.setLayout(cardLayout);

        // Role-Based Sidebar & Content
        String role = user.getRole();
        if (role.equals("Customer")) {
            addSidebarItem("My Dashboard", "🏠", new CustomerDashboardPanel(this, user));
            addSidebarItem("Available Rooms", "🛏", new RoomPanel(user.getRole()));
            addSidebarItem("My Bookings", "📅", new BookingPanel(user));
            addSidebarItem("Order Food", "🍲", new ServicePanel(user));
            addSidebarItem("Feedback", "⭐", new FeedbackPanel(user));
        } else if (role.equals("Manager")) {
            addSidebarItem("Manager Dashboard", "🏠", new DashboardPanel("Ethiopia Hotel Manager Dashboard", user));
            addSidebarItem("Guests", "👤", new GuestPanel());
            addSidebarItem("Rooms", "🛏", new RoomPanel(user.getRole()));
            addSidebarItem("Bookings", "📅", new BookingPanel(user));
            addSidebarItem("Reception/Staff", "💼", new EmployeePanel());
        } else {
            addSidebarItem("Admin Dashboard", "🏠", new DashboardPanel("Ethiopia Hotel Admin Dashboard", user));
            if (role.equals("Admin") || role.equals("Receptionist")) {
                addSidebarItem("Guests", "👤", new GuestPanel());
                addSidebarItem("Rooms", "🛏", new RoomPanel(user.getRole()));
                addSidebarItem("Bookings", "📅", new BookingPanel(user));
            }
            if (role.equals("Admin")) {
                addSidebarItem("Reception/Staff", "💼", new EmployeePanel());
            }
        }


        add(sidebar, BorderLayout.WEST);

        // --- Top Bar ---
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(Color.WHITE);
        topBar.setPreferredSize(new Dimension(0, 70));
        topBar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(230, 230, 230)));

        JLabel pageTitle = new JLabel("  System Overview");
        pageTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        topBar.add(pageTitle, BorderLayout.WEST);

        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 15));
        userPanel.setOpaque(false);
        
        JLabel userInfo = new JLabel(user.getUsername() + " (" + user.getRole() + ")");
        userInfo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        
        JButton logoutBtn = new JButton("LOGOUT");
        logoutBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        logoutBtn.setBackground(new Color(200, 0, 0));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFocusPainted(false);
        logoutBtn.addActionListener(e -> handleLogout());

        userPanel.add(userInfo);
        userPanel.add(logoutBtn);
        topBar.add(userPanel, BorderLayout.EAST);

        add(topBar, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);
    }

    public void showPanel(String name) {
        cardLayout.show(contentPanel, name);
        
        // Highlight corresponding button
        for (Component c : sidebar.getComponents()) {
            if (c instanceof JButton) {
                JButton b = (JButton) c;
                if (b.getText().contains(name)) {
                    b.setBackground(accentColor);
                    b.setForeground(Color.BLACK);
                } else {
                    b.setBackground(sidebarColor);
                    b.setForeground(Color.WHITE);
                }
            }
        }

        // Auto-refresh logic for data panels
        for (Component comp : contentPanel.getComponents()) {
            if (comp.isVisible()) {
                if (comp instanceof BookingPanel) {
                    ((BookingPanel) comp).loadData();
                }
                break;
            }
        }
    }

    private void addSidebarItem(String name, String icon, JPanel panel) {
        contentPanel.add(panel, name);
        
        JButton btn = new JButton(icon + "   " + name);
        btn.setMaximumSize(new Dimension(250, 60));
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btn.setForeground(Color.WHITE);
        btn.setBackground(sidebarColor);
        btn.setBorder(new EmptyBorder(0, 30, 0, 0));
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) {
                if (!btn.getBackground().equals(accentColor)) {
                    btn.setBackground(hoverColor);
                }
            }
            public void mouseExited(java.awt.event.MouseEvent e) {
                if (!btn.getBackground().equals(accentColor)) {
                    btn.setBackground(sidebarColor);
                }
            }
        });

        btn.addActionListener(e -> showPanel(name));
        sidebar.add(btn);
        sidebar.add(Box.createVerticalStrut(5));
    }


    private void handleLogout() {
        if (JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            new LoginFrame().setVisible(true);
            dispose();
        }
    }
}
