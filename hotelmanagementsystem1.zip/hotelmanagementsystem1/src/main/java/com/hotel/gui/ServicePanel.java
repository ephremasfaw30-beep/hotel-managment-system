package com.hotel.gui;

import com.hotel.model.User;
import com.hotel.dao.UserDAO;
import com.hotel.util.StyleUtils;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class ServicePanel extends JPanel {
    private Color primaryColor = new Color(0, 100, 0); // Ethiopia Green
    private User currentUser;
    private UserDAO userDAO = new UserDAO();

    public ServicePanel(User user) {
        this.currentUser = user;
        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 250));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(new EmptyBorder(20, 30, 20, 30));
        JLabel title = new JLabel("Food & Room Services");
        title.setFont(new Font("Serif", Font.BOLD, 28));
        title.setForeground(primaryColor);
        header.add(title, BorderLayout.WEST);
        add(header, BorderLayout.NORTH);

        // Content
        JPanel grid = new JPanel(new GridLayout(0, 3, 20, 20));
        grid.setOpaque(false);
        grid.setBorder(new EmptyBorder(30, 30, 30, 30));

        addServiceItem(grid, "Traditional Tibs", "Beef sautéed with onions and peppers", "450 ETB", "🍲");
        addServiceItem(grid, "Doro Wat", "Spicy chicken stew with egg", "600 ETB", "🍛");
        addServiceItem(grid, "Kitfo", "Minced raw beef with spices", "550 ETB", "🥩");
        addServiceItem(grid, "Ethiopian Coffee", "Traditional ceremonial coffee", "150 ETB", "☕");
        addServiceItem(grid, "Fresh Juice", "Seasonal fruit mix", "200 ETB", "🍹");
        addServiceItem(grid, "Laundry Service", "Express wash and iron", "300 ETB", "🧺");

        add(new JScrollPane(grid), BorderLayout.CENTER);
    }

    private void addServiceItem(JPanel container, String name, String desc, String price, String icon) {
        JPanel card = new JPanel(new BorderLayout(10, 10));
        card.setBackground(Color.WHITE);
        card.setBorder(new EmptyBorder(15, 15, 15, 15));
        
        JLabel iconLbl = new JLabel(icon);
        iconLbl.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 40));
        card.add(iconLbl, BorderLayout.WEST);

        JPanel info = new JPanel(new GridLayout(3, 1));
        info.setOpaque(false);
        JLabel nameLbl = new JLabel(name);
        nameLbl.setFont(new Font("Segoe UI", Font.BOLD, 16));
        JLabel descLbl = new JLabel(desc);
        descLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLbl.setForeground(Color.GRAY);
        JLabel priceLbl = new JLabel(price);
        priceLbl.setForeground(primaryColor);
        priceLbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        
        info.add(nameLbl);
        info.add(descLbl);
        info.add(priceLbl);
        card.add(info, BorderLayout.CENTER);

        JButton orderBtn = new JButton("Order Now");
        StyleUtils.applyPrimaryStyle(orderBtn);
        orderBtn.addActionListener(e -> handleOrder(name, price));
        card.add(orderBtn, BorderLayout.SOUTH);
        container.add(card);
    }

    private void handleOrder(String itemName, String priceStr) {
        double cost = Double.parseDouble(priceStr.replace(" ETB", ""));
        
        String[] methods = {"My Wallet", "Abyssinia Bank", "CBE Birr", "Telebirr"};
        String method = (String) JOptionPane.showInputDialog(this, 
                "Order: " + itemName + "\nCost: " + cost + " ETB\nSelect Payment Method:", 
                "Confirm Order", JOptionPane.QUESTION_MESSAGE, null, methods, methods[0]);
                
        if (method == null) return;
        
        try {
            if ("My Wallet".equals(method)) {
                if (currentUser.getBalance() < cost) {
                    JOptionPane.showMessageDialog(this, "Insufficient wallet balance.");
                    return;
                }
                double newBal = currentUser.getBalance() - cost;
                userDAO.updateBalance(currentUser.getId(), newBal);
                currentUser.setBalance(newBal);
            }
            
            // Notify Admins
            List<User> admins = userDAO.getUsersByRole("Admin");
            String msg = "ROOM SERVICE REQUEST: " + currentUser.getFullName() + " ordered " + itemName + " (" + method + " payment).";
            for (User admin : admins) {
                userDAO.sendNotification(admin.getId(), msg);
            }
            
            JOptionPane.showMessageDialog(this, "Order placed successfully! The admin has been notified.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error placing order: " + ex.getMessage());
        }
    }
}
