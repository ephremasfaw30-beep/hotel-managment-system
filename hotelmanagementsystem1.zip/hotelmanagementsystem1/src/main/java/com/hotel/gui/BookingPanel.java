package com.hotel.gui;

import com.hotel.dao.BookingDAO;
import com.hotel.dao.GuestDAO;
import com.hotel.dao.RoomDAO;
import com.hotel.model.Booking;
import com.hotel.model.Guest;
import com.hotel.model.Room;
import com.hotel.util.StyleUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Vector;

public class BookingPanel extends JPanel {
    private BookingDAO bookingDAO = new BookingDAO();
    private GuestDAO guestDAO = new GuestDAO();
    private RoomDAO roomDAO = new RoomDAO();
    
    private JTable bookingTable;
    private DefaultTableModel tableModel;
    private com.hotel.model.User currentUser;
    private com.hotel.dao.UserDAO userDAO = new com.hotel.dao.UserDAO();

    public BookingPanel() {
        this(new com.hotel.model.User(0, "Admin", "admin", "admin@hotel.com", "admin", "", "Admin", 0.0));
    }

    public BookingPanel(com.hotel.model.User user) {
        this.currentUser = user;
        String role = user.getRole();
        setLayout(new BorderLayout());

        // Top Bar
        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topBar.setBackground(Color.WHITE);
        topBar.setBorder(new javax.swing.border.EmptyBorder(15, 20, 15, 20));

        JButton refreshBtn = new JButton("🔄 Refresh");
        JButton addBtn = new JButton("➕ New Booking");
        JButton checkoutBtn = new JButton("🚪 Check-Out");
        JButton notifyBtn = new JButton("🔔 Notify Checkout");
        JButton deleteBtn = new JButton("🗑 Delete Record");
        JButton viewNotesBtn = new JButton("🔔 Notifications");

        StyleUtils.applyPrimaryStyle(refreshBtn);
        StyleUtils.applyPrimaryStyle(addBtn);
        StyleUtils.applyPrimaryStyle(checkoutBtn);
        StyleUtils.applyModernStyle(notifyBtn, new Color(255, 205, 0), Color.BLACK); // Gold for notify
        StyleUtils.applyDangerStyle(deleteBtn);
        StyleUtils.applyModernStyle(viewNotesBtn, new Color(255, 205, 0), Color.BLACK); // Gold for Notifications

        topBar.add(refreshBtn);
        topBar.add(Box.createHorizontalGlue());
        
        if (!"Customer".equals(role)) {
            topBar.add(addBtn);
            topBar.add(checkoutBtn);
            topBar.add(notifyBtn);
            topBar.add(deleteBtn);
        }
        topBar.add(viewNotesBtn); // Visible to everyone

        add(topBar, BorderLayout.NORTH);

        // Table
        tableModel = new DefaultTableModel(new String[]{
            "ID", "Guest", "Room", "Check-In", "Check-Out", "Amount", "Status"
        }, 0);
        bookingTable = new JTable(tableModel);
        add(new JScrollPane(bookingTable), BorderLayout.CENTER);

        // Events
        refreshBtn.addActionListener(e -> loadData());
        
        if (!"Customer".equals(role)) {
            addBtn.addActionListener(e -> showBookingDialog());
            checkoutBtn.addActionListener(e -> handleCheckout());
            notifyBtn.addActionListener(e -> handleNotify());
            deleteBtn.addActionListener(e -> handleDelete());
        }
        viewNotesBtn.addActionListener(e -> showCustomerNotifications());

        loadData();
    }


    public void loadData() {
        try {
            tableModel.setRowCount(0);
            List<Booking> bookings = bookingDAO.getAllBookings();
            
            // Filter if customer
            if ("Customer".equals(currentUser.getRole())) {
                com.hotel.dao.GuestDAO guestDAO = new com.hotel.dao.GuestDAO();
                com.hotel.model.Guest guest = guestDAO.getGuestByEmail(currentUser.getEmail());
                if (guest != null) {
                    int guestId = guest.getId();
                    bookings = bookings.stream()
                            .filter(b -> b.getGuestId() == guestId)
                            .toList();
                } else {
                    bookings.clear();
                }
            }

            for (Booking b : bookings) {
                tableModel.addRow(new Object[]{
                    b.getId(), b.getGuestName(), b.getRoomNumber(), 
                    b.getCheckInDate(), b.getCheckOutDate(), 
                    b.getTotalAmount(), b.getStatus()
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void handleCheckout() {
        int row = bookingTable.getSelectedRow();
        if (row != -1) {
            int id = (int) tableModel.getValueAt(row, 0);
            try {
                List<Booking> all = bookingDAO.getAllBookings();
                Booking booking = all.stream().filter(b -> b.getId() == id).findFirst().orElse(null);
                if (booking != null && "Confirmed".equals(booking.getStatus())) {
                    booking.setStatus("Checked-Out");
                    bookingDAO.updateBooking(booking);
                    loadData();
                } else {
                    JOptionPane.showMessageDialog(this, "Only confirmed bookings can be checked out.");
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            }
        }
    }

    private void handleDelete() {
        int row = bookingTable.getSelectedRow();
        if (row != -1) {
            int id = (int) tableModel.getValueAt(row, 0);
            if (JOptionPane.showConfirmDialog(this, "Delete booking record?") == JOptionPane.YES_OPTION) {
                try {
                    bookingDAO.deleteBooking(id);
                    loadData();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
                }
            }
        }
    }

    private void handleNotify() {
        int row = bookingTable.getSelectedRow();
        if (row != -1) {
            String guestName = (String) tableModel.getValueAt(row, 1);
            String roomNo = (String) tableModel.getValueAt(row, 2);
            String status = (String) tableModel.getValueAt(row, 6);
            
            if ("Checked-Out".equalsIgnoreCase(status)) {
                JOptionPane.showMessageDialog(this, "Customer already checked out.");
                return;
            }

            // Creating a beautiful notification dialog
            JPanel p = new JPanel(new BorderLayout(10, 10));
            p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            JLabel icon = new JLabel("📧");
            icon.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 40));
            p.add(icon, BorderLayout.WEST);
            
            String msg = String.format("<html><b>NOTIFICATION SENT</b><br><br>" +
                         "To: %s<br>Room: %s<br><br>" +
                         "Message: <i>'Dear %s, your checkout for Room %s is scheduled today. Please proceed to reception.'</i></html>",
                         guestName, roomNo, guestName, roomNo);
            
            p.add(new JLabel(msg), BorderLayout.CENTER);
            
            // SAVE TO DATABASE
            try {
                // Find guest user ID from booking (assuming guest name matches a user or we use booking guest_id)
                // For simplicity, we send to the guest associated with the booking
                userDAO.sendNotification(bookingDAO.getAllBookings().stream()
                    .filter(b -> b.getGuestName().equals(guestName))
                    .findFirst().map(b -> b.getGuestId()).orElse(0), 
                    "Checkout Reminder: Dear " + guestName + ", your checkout for Room " + roomNo + " is scheduled today.");
            } catch (Exception ex) {
                ex.printStackTrace();
            }

            JOptionPane.showMessageDialog(this, p, "System Notification", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a booking row to notify.");
        }
    }

    private void showCustomerNotifications() {
        try {
            List<String> notes = userDAO.getNotifications(currentUser.getId());
            if (notes.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No new notifications.");
                return;
            }
            
            JPanel p = new JPanel();
            p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
            for (String n : notes) {
                JLabel l = new JLabel("<html><div style='width:300px; padding:10px; margin-bottom:5px; background:white; border:1px solid #ddd;'>" + n + "</div></html>");
                p.add(l);
            }
            JOptionPane.showMessageDialog(this, new JScrollPane(p), "My Notifications", JOptionPane.PLAIN_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void showBookingDialog() {
        try {
            List<Guest> guests = guestDAO.getAllGuests();
            List<Room> rooms = roomDAO.getAllRooms().stream()
                    .filter(r -> "Available".equals(r.getStatus())).toList();

            if (guests.isEmpty() || rooms.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Need at least one guest and one available room.");
                return;
            }

            JComboBox<Guest> guestBox = new JComboBox<>(new Vector<>(guests));
            JComboBox<Room> roomBox = new JComboBox<>(new Vector<>(rooms));
            JTextField checkInField = new JTextField(LocalDate.now().toString());
            JTextField checkOutField = new JTextField(LocalDate.now().plusDays(1).toString());

            JPanel panel = new JPanel(new GridLayout(4, 2));
            panel.add(new JLabel("Guest:")); panel.add(guestBox);
            panel.add(new JLabel("Room:")); panel.add(roomBox);
            panel.add(new JLabel("Check-In (YYYY-MM-DD):")); panel.add(checkInField);
            panel.add(new JLabel("Check-Out (YYYY-MM-DD):")); panel.add(checkOutField);

            if (JOptionPane.showConfirmDialog(null, panel, "New Booking", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                Guest guest = (Guest) guestBox.getSelectedItem();
                Room room = (Room) roomBox.getSelectedItem();
                LocalDate in = LocalDate.parse(checkInField.getText());
                LocalDate out = LocalDate.parse(checkOutField.getText());

                long days = ChronoUnit.DAYS.between(in, out);
                if (days <= 0) days = 1; // Minimum 1 day
                double amount = days * room.getPrice();

                Booking b = new Booking(0, guest.getId(), room.getId(), in, out, amount, "Confirmed", null, null);
                bookingDAO.addBooking(b);
                loadData();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}
