package com.hotel.gui;

import com.hotel.model.User;
import com.hotel.dao.UserDAO;
import com.hotel.dao.BookingDAO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import com.hotel.util.StyleUtils;

public class PaymentPanel extends JPanel {
    private Color primaryColor = new Color(0, 100, 0); // Ethiopia Green
    private BookingDAO bookingDAO = new BookingDAO();
    private UserDAO userDAO = new UserDAO();
    private JLabel billLabel = new JLabel("0.00 ETB");
    private JLabel walletLabel = new JLabel("0.00 ETB");
    private JComboBox<com.hotel.model.Booking> bookingCombo;
    private User currentUser;

    public PaymentPanel(User user) {
        this.currentUser = user;
        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 250));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(new EmptyBorder(20, 30, 20, 30));
        JLabel title = new JLabel("Ethiopia Hotel - Payments & Billing");
        title.setFont(new Font("Serif", Font.BOLD, 28));
        title.setForeground(primaryColor);
        header.add(title, BorderLayout.WEST);
        
        // Wallet Info in Header
        JPanel walletInfo = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        walletInfo.setOpaque(false);
        JLabel wText = new JLabel("Your Wallet Balance: ");
        wText.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        walletLabel.setText(String.format("%.2f ETB", user.getBalance()));
        walletLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        walletLabel.setForeground(new Color(0, 150, 0));
        walletInfo.add(wText);
        walletInfo.add(walletLabel);
        header.add(walletInfo, BorderLayout.EAST);
        
        add(header, BorderLayout.NORTH);

        // Content Area
        JPanel mainContent = new JPanel(new GridBagLayout());
        mainContent.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.BOTH;

        // --- Left: Billing Summary Card ---
        JPanel billingCard = new JPanel(new BorderLayout(10, 20));
        billingCard.setBackground(Color.WHITE);
        billingCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(230, 230, 230)),
            new EmptyBorder(25, 25, 25, 25)
        ));
        billingCard.setPreferredSize(new Dimension(450, 350));

        JLabel summaryTitle = new JLabel("Pending Payments");
        summaryTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        billingCard.add(summaryTitle, BorderLayout.NORTH);

        // Selection Panel
        JPanel selectionPanel = new JPanel(new GridLayout(4, 1, 5, 5));
        selectionPanel.setOpaque(false);
        
        selectionPanel.add(new JLabel("Select Booking to Pay:"));
        bookingCombo = new JComboBox<>();
        loadUnpaidBookings();
        bookingCombo.addActionListener(e -> updateBillLabel());
        selectionPanel.add(bookingCombo);
        
        selectionPanel.add(new JLabel("Total Bill Amount:"));
        billLabel.setFont(new Font("Segoe UI", Font.BOLD, 36));
        billLabel.setForeground(new Color(180, 0, 0));
        selectionPanel.add(billLabel);
        
        billingCard.add(selectionPanel, BorderLayout.CENTER);

        JButton payNow = new JButton("💳 COMPLETE PAYMENT NOW");
        StyleUtils.applyPrimaryStyle(payNow);
        payNow.setPreferredSize(new Dimension(0, 65));
        payNow.addActionListener(e -> processPayment("Wallet"));
        billingCard.add(payNow, BorderLayout.SOUTH);

        gbc.gridx = 0; gbc.gridy = 0;
        mainContent.add(billingCard, gbc);

        // --- Right: Quick Pay Methods ---
        JPanel methodsPanel = new JPanel(new GridLayout(3, 1, 15, 15));
        methodsPanel.setOpaque(false);
        
        methodsPanel.add(createMethodButton("Telebirr", "📱", new Color(0, 100, 255)));
        methodsPanel.add(createMethodButton("CBE Birr", "🏦", new Color(150, 0, 150)));
        methodsPanel.add(createMethodButton("HelloCash", "💸", new Color(0, 150, 0)));

        gbc.gridx = 1;
        mainContent.add(methodsPanel, gbc);

        add(new JScrollPane(mainContent), BorderLayout.CENTER);
        updateBillLabel();
    }

    private void loadUnpaidBookings() {
        try {
            java.util.List<com.hotel.model.Booking> all = bookingDAO.getAllBookings();
            bookingCombo.removeAllItems();
            com.hotel.dao.GuestDAO guestDAO = new com.hotel.dao.GuestDAO();
            com.hotel.model.Guest guest = guestDAO.getGuestByEmail(currentUser.getEmail());
            int guestId = (guest != null) ? guest.getId() : -1;

            for (com.hotel.model.Booking b : all) {
                // Filter by current customer
                if (!"Paid".equalsIgnoreCase(b.getStatus()) && b.getGuestId() == guestId) {
                    bookingCombo.addItem(b);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateBillLabel() {
        com.hotel.model.Booking b = (com.hotel.model.Booking) bookingCombo.getSelectedItem();
        if (b != null) {
            billLabel.setText(String.format("%.2f ETB", b.getTotalAmount()));
        } else {
            billLabel.setText("0.00 ETB");
        }
    }

    private void processPayment(String gateway) {
        com.hotel.model.Booking b = (com.hotel.model.Booking) bookingCombo.getSelectedItem();
        if (b == null) {
            JOptionPane.showMessageDialog(this, "Please select a booking to pay.");
            return;
        }

        double amount = b.getTotalAmount();
        if (currentUser.getBalance() < amount) {
            JOptionPane.showMessageDialog(this, "Insufficient Wallet Balance!\nYour Balance: " + currentUser.getBalance() + " ETB\nRequired: " + amount + " ETB", "Payment Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Simulating processing
        JDialog dialog = new JDialog();
        dialog.setTitle("Processing Payment...");
        dialog.setSize(300, 150);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        JLabel status = new JLabel("Connecting to " + gateway + "...", SwingConstants.CENTER);
        dialog.add(status, BorderLayout.CENTER);
        
        Timer timer = new Timer(1500, e -> {
            try {
                // Update Booking
                b.setStatus("Paid");
                bookingDAO.updateBooking(b);
                
                // Update Wallet
                double newBalance = currentUser.getBalance() - amount;
                userDAO.updateBalance(currentUser.getId(), newBalance);
                currentUser.setBalance(newBalance);
                
                dialog.dispose();
                walletLabel.setText(String.format("%.2f ETB", newBalance));
                showDigitalReceipt(b, gateway);
                loadUnpaidBookings();
                updateBillLabel();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Payment failed: " + ex.getMessage());
            }
        });
        timer.setRepeats(false);
        timer.start();
        dialog.setVisible(true);
    }

    private void showDigitalReceipt(com.hotel.model.Booking b, String gateway) {
        String receipt = String.format(
            "==================================\n" +
            "      ETHIOPIA HOTEL RECEIPT      \n" +
            "==================================\n" +
            "Booking ID: #%d\n" +
            "Date: %s\n" +
            "Gateway: %s\n" +
            "Amount Paid: %.2f ETB\n" +
            "New Wallet Balance: %.2f ETB\n" +
            "Status: SUCCESSFUL\n" +
            "==================================\n" +
            "Thank you for choosing Ethiopia Hotel!",
            b.getId(), java.time.LocalDateTime.now().toString(), gateway, b.getTotalAmount(), currentUser.getBalance()
        );
        
        JTextArea area = new JTextArea(receipt);
        area.setFont(new Font("Monospaced", Font.PLAIN, 14));
        area.setEditable(false);
        JOptionPane.showMessageDialog(this, new JScrollPane(area), "Digital Receipt", JOptionPane.INFORMATION_MESSAGE);
    }

    private JButton createMethodButton(String name, String icon, Color color) {
        JButton b = new JButton("<html><center><font size='6'>" + icon + "</font><br><b>Pay via " + name + "</b></center></html>");
        b.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        b.setBackground(Color.WHITE);
        b.setForeground(color);
        b.setBorder(BorderFactory.createLineBorder(color, 2));
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(250, 100));
        b.addActionListener(e -> processPayment(name));
        return b;
    }

}
