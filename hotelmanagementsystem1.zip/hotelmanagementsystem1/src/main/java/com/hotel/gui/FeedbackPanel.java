package com.hotel.gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import com.hotel.util.StyleUtils;
import com.hotel.model.User;
import com.hotel.dao.UserDAO;
import java.util.List;

public class FeedbackPanel extends JPanel {
    private Color primaryColor = new Color(0, 100, 0); // Ethiopia Green
    private User currentUser;
    private UserDAO userDAO = new UserDAO();
    
    public FeedbackPanel(User user) {
        this.currentUser = user;
        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 250));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(new EmptyBorder(20, 30, 20, 30));
        JLabel title = new JLabel("Guest Feedback & Reviews");
        title.setFont(new Font("Serif", Font.BOLD, 28));
        title.setForeground(primaryColor);
        header.add(title, BorderLayout.WEST);
        add(header, BorderLayout.NORTH);

        // Form
        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        form.setBorder(new EmptyBorder(40, 100, 40, 100));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        JLabel ratingLbl = new JLabel("Rate your experience (1-5):");
        ratingLbl.setFont(new Font("Segoe UI", Font.BOLD, 16));
        gbc.gridx = 0; gbc.gridy = 0;
        form.add(ratingLbl, gbc);

        JComboBox<String> ratingBox = new JComboBox<>(new String[]{"⭐⭐⭐⭐⭐ (Excellent)", "⭐⭐⭐⭐ (Very Good)", "⭐⭐⭐ (Average)", "⭐⭐ (Poor)", "⭐ (Terrible)"});
        gbc.gridy = 1;
        form.add(ratingBox, gbc);

        JLabel commentLbl = new JLabel("Tell us more:");
        commentLbl.setFont(new Font("Segoe UI", Font.BOLD, 16));
        gbc.gridy = 2;
        form.add(commentLbl, gbc);

        JTextArea commentArea = new JTextArea(5, 20);
        commentArea.setLineWrap(true);
        commentArea.setWrapStyleWord(true);
        gbc.gridy = 3;
        form.add(new JScrollPane(commentArea), gbc);

        JButton submitBtn = new JButton("⭐ SUBMIT FEEDBACK");
        StyleUtils.applyPrimaryStyle(submitBtn);
        submitBtn.setPreferredSize(new Dimension(0, 55));
        submitBtn.addActionListener(e -> {
            String rating = (String) ratingBox.getSelectedItem();
            String comments = commentArea.getText();
            if (comments.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter your comments before submitting.");
                return;
            }
            try {
                List<User> admins = userDAO.getUsersByRole("Admin");
                String msg = "GUEST FEEDBACK from " + currentUser.getFullName() + "\nRating: " + rating + "\nComments: " + comments;
                for (User admin : admins) {
                    userDAO.sendNotification(admin.getId(), msg);
                }
                JOptionPane.showMessageDialog(this, "Thank you for your feedback! We value your input and our Admin team has been notified.");
                commentArea.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error submitting feedback: " + ex.getMessage());
            }
        });
        gbc.gridy = 4;
        form.add(submitBtn, gbc);

        add(form, BorderLayout.CENTER);
    }
}
