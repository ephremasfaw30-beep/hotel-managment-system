package com.hotel.gui;

import com.hotel.dao.EmployeeDAO;
import com.hotel.model.Employee;
import com.hotel.util.StyleUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class EmployeePanel extends JPanel {
    private EmployeeDAO employeeDAO = new EmployeeDAO();
    private JTable employeeTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;

    public EmployeePanel() {
        setLayout(new BorderLayout());

        // Top Bar
        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topBar.setBackground(Color.WHITE);
        topBar.setBorder(new javax.swing.border.EmptyBorder(15, 20, 15, 20));

        searchField = new JTextField(15);
        searchField.setPreferredSize(new Dimension(150, 35));

        JButton searchBtn = new JButton("🔍 Search");
        JButton refreshBtn = new JButton("🔄 Refresh");
        JButton addBtn = new JButton("➕ Add Employee");
        JButton updateBtn = new JButton("📝 Update");
        JButton salaryBtn = new JButton("💰 Salary");
        JButton promoteBtn = new JButton("📈 Promote");
        JButton statsBtn = new JButton("📊 Stats");
        JButton deleteBtn = new JButton("🗑 Delete");

        StyleUtils.applySecondaryStyle(searchBtn);
        StyleUtils.applySecondaryStyle(refreshBtn);
        StyleUtils.applyPrimaryStyle(addBtn);
        StyleUtils.applyPrimaryStyle(updateBtn);
        StyleUtils.applyPrimaryStyle(salaryBtn);
        StyleUtils.applyPrimaryStyle(promoteBtn);
        StyleUtils.applySecondaryStyle(statsBtn);
        StyleUtils.applyDangerStyle(deleteBtn);

        topBar.add(new JLabel("Search: "));
        topBar.add(searchField);
        topBar.add(searchBtn);
        topBar.add(Box.createHorizontalStrut(10));
        topBar.add(refreshBtn);
        topBar.add(Box.createHorizontalGlue());
        topBar.add(addBtn);
        topBar.add(updateBtn);
        topBar.add(salaryBtn);
        topBar.add(promoteBtn);
        topBar.add(statsBtn);
        topBar.add(deleteBtn);

        add(topBar, BorderLayout.NORTH);


        // Table
        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Role", "Salary", "Phone", "Hire Date"}, 0);
        employeeTable = new JTable(tableModel);
        employeeTable.setRowHeight(25);
        add(new JScrollPane(employeeTable), BorderLayout.CENTER);

        // Events
        searchBtn.addActionListener(e -> performSearch());
        refreshBtn.addActionListener(e -> loadData());
        addBtn.addActionListener(e -> showEmployeeDialog(null));
        updateBtn.addActionListener(e -> {
            int row = employeeTable.getSelectedRow();
            if (row != -1) {
                int id = (int) tableModel.getValueAt(row, 0);
                showEmployeeDialog(id);
            }
        });
        salaryBtn.addActionListener(e -> handleSalaryIncrease());
        promoteBtn.addActionListener(e -> handlePromotion());
        statsBtn.addActionListener(e -> showRoleStats());
        deleteBtn.addActionListener(e -> {
            int row = employeeTable.getSelectedRow();
            if (row != -1) {
                int id = (int) tableModel.getValueAt(row, 0);
                if (JOptionPane.showConfirmDialog(this, "Delete employee record?") == JOptionPane.YES_OPTION) {
                    try {
                        employeeDAO.deleteEmployee(id);
                        loadData();
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
                    }
                }
            }
        });

        loadData();
    }

    private void handleSalaryIncrease() {
        int row = employeeTable.getSelectedRow();
        if (row != -1) {
            String amountStr = JOptionPane.showInputDialog(this, "Enter percentage increase (e.g., 10 for 10%):");
            if (amountStr != null) {
                try {
                    double percent = Double.parseDouble(amountStr) / 100.0;
                    int id = (int) tableModel.getValueAt(row, 0);
                    Employee e = employeeDAO.searchEmployees(String.valueOf(id)).get(0);
                    e.setSalary(e.getSalary() * (1 + percent));
                    employeeDAO.updateEmployee(e);
                    loadData();
                    JOptionPane.showMessageDialog(this, "Salary updated successfully!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Invalid amount.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Select an employee first.");
        }
    }

    private void handlePromotion() {
        int row = employeeTable.getSelectedRow();
        if (row != -1) {
            String[] roles = {"Manager", "Receptionist", "Housekeeping", "Chef", "Security"};
            String newRole = (String) JOptionPane.showInputDialog(this, "Select New Role:", "Promote Employee",
                    JOptionPane.QUESTION_MESSAGE, null, roles, roles[0]);
            
            if (newRole != null) {
                try {
                    int id = (int) tableModel.getValueAt(row, 0);
                    Employee e = employeeDAO.searchEmployees(String.valueOf(id)).get(0);
                    e.setRole(newRole);
                    employeeDAO.updateEmployee(e);
                    loadData();
                    JOptionPane.showMessageDialog(this, "Employee promoted to " + newRole + "!");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Error during promotion.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Select an employee first.");
        }
    }

    private void showRoleStats() {
        try {
            List<Employee> all = employeeDAO.getAllEmployees();
            java.util.Map<String, Long> stats = all.stream()
                    .collect(java.util.stream.Collectors.groupingBy(Employee::getRole, java.util.stream.Collectors.counting()));
            
            StringBuilder sb = new StringBuilder("Staff Distribution:\n");
            stats.forEach((role, count) -> sb.append(role).append(": ").append(count).append("\n"));
            JOptionPane.showMessageDialog(this, sb.toString());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error calculating stats.");
        }
    }


    private void loadData() {
        try {
            updateTable(employeeDAO.getAllEmployees());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void performSearch() {
        try {
            updateTable(employeeDAO.searchEmployees(searchField.getText()));
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void updateTable(List<Employee> employees) {
        tableModel.setRowCount(0);
        for (Employee e : employees) {
            tableModel.addRow(new Object[]{e.getId(), e.getName(), e.getRole(), e.getSalary(), e.getPhone(), e.getHireDate()});
        }
    }

    private void showEmployeeDialog(Integer employeeId) {
        Employee employee = null;
        if (employeeId != null) {
            try {
                employee = employeeDAO.searchEmployees(String.valueOf(employeeId)).stream()
                        .filter(e -> e.getId() == employeeId).findFirst().orElse(null);
            } catch (SQLException e) {}
        }

        JTextField nameField = new JTextField(employee != null ? employee.getName() : "");
        JComboBox<String> roleBox = new JComboBox<>(new String[]{"Manager", "Receptionist", "Housekeeping", "Chef", "Security"});
        if (employee != null) roleBox.setSelectedItem(employee.getRole());
        
        JTextField salaryField = new JTextField(employee != null ? String.valueOf(employee.getSalary()) : "0.0");
        JTextField phoneField = new JTextField(employee != null ? employee.getPhone() : "");

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("Name:")); panel.add(nameField);
        panel.add(new JLabel("Role:")); panel.add(roleBox);
        panel.add(new JLabel("Salary:")); panel.add(salaryField);
        panel.add(new JLabel("Phone:")); panel.add(phoneField);

        if (JOptionPane.showConfirmDialog(null, panel, employeeId == null ? "Add Employee" : "Update Employee", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            try {
                Employee e = new Employee(employeeId != null ? employeeId : 0, nameField.getText(), 
                        (String) roleBox.getSelectedItem(), Double.parseDouble(salaryField.getText()), 
                        phoneField.getText(), employee != null ? employee.getHireDate() : LocalDate.now());
                if (employeeId == null) employeeDAO.addEmployee(e);
                else employeeDAO.updateEmployee(e);
                loadData();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        }
    }
}
