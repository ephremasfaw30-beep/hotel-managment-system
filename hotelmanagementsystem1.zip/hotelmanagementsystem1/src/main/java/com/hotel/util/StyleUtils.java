package com.hotel.util;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class StyleUtils {
    public static final Color ETHIOPIA_GREEN = new Color(0, 100, 0);
    public static final Color ETHIOPIA_GOLD = new Color(255, 205, 0);
    public static final Color ACCENT_RED = new Color(200, 0, 0);
    public static final Color BACKGROUND_LIGHT = new Color(245, 245, 250);

    public static void applyModernStyle(JButton button, Color bg, Color fg) {
        button.setBackground(bg);
        button.setForeground(fg);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(new EmptyBorder(10, 20, 10, 20));
        
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(bg.brighter());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(bg);
            }
        });
    }

    public static void applyPrimaryStyle(JButton button) {
        applyModernStyle(button, ETHIOPIA_GREEN, Color.WHITE);
    }

    public static void applySecondaryStyle(JButton button) {
        applyModernStyle(button, Color.WHITE, ETHIOPIA_GREEN);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(ETHIOPIA_GREEN, 1),
            new EmptyBorder(10, 20, 10, 20)
        ));
    }

    public static void applyDangerStyle(JButton button) {
        applyModernStyle(button, ACCENT_RED, Color.WHITE);
    }
}
