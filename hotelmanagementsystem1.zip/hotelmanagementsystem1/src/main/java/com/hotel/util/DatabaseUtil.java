package com.hotel.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Manages database connectivity with MySQL primary and SQLite fallback.
 * SQLite schema is initialized inline (SQLite-compatible syntax only).
 */
public class DatabaseUtil {

    private static final String MYSQL_URL =
            "jdbc:mysql://localhost:3306/hotel_db?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true";
    private static final String MYSQL_USER = "root";
    private static final String MYSQL_PASS = "";

    private static final String SQLITE_URL = "jdbc:sqlite:db/hotel.db";

    /** true = connected to MySQL, false = using SQLite fallback */
    private static boolean usingMySQL = false;

    static {
        // Attempt MySQL first; if it fails, fall back to SQLite and create tables.
        try {
            Connection test = DriverManager.getConnection(MYSQL_URL, MYSQL_USER, MYSQL_PASS);
            test.close();
            usingMySQL = true;
            initializeMySQLSchema();
            System.out.println("Connected to MySQL successfully.");
        } catch (SQLException e) {
            System.err.println("MySQL unavailable – using SQLite fallback. (" + e.getMessage() + ")");
            usingMySQL = false;
            
            // Ensure the 'db' directory exists
            java.io.File dbDir = new java.io.File("db");
            if (!dbDir.exists()) {
                dbDir.mkdirs();
            }
            
            initializeSQLiteSchema();
        }
    }

    public static Connection getConnection() throws SQLException {
        if (usingMySQL) {
            return DriverManager.getConnection(MYSQL_URL, MYSQL_USER, MYSQL_PASS);
        } else {
            return DriverManager.getConnection(SQLITE_URL);
        }
    }

    // ---------------------------------------------------------------
    // MySQL schema initialisation (reads from schema.sql if needed,
    // but we keep it simple – MySQL auto-creates via CREATE TABLE IF NOT EXISTS)
    // ---------------------------------------------------------------
    private static void initializeMySQLSchema() {
        String[] ddl = {
            "CREATE TABLE IF NOT EXISTS guests (" +
            "  id INT PRIMARY KEY AUTO_INCREMENT," +
            "  name VARCHAR(255) NOT NULL," +
            "  email VARCHAR(191) UNIQUE," +
            "  phone VARCHAR(20) NOT NULL," +
            "  address TEXT," +
            "  created_at DATETIME DEFAULT CURRENT_TIMESTAMP" +
            ")",

            "CREATE TABLE IF NOT EXISTS rooms (" +
            "  id INT PRIMARY KEY AUTO_INCREMENT," +
            "  room_number VARCHAR(50) NOT NULL UNIQUE," +
            "  type VARCHAR(50) NOT NULL," +
            "  price DECIMAL(10,2) NOT NULL," +
            "  status VARCHAR(20) DEFAULT 'Available'," +
            "  description TEXT" +
            ")",

            "CREATE TABLE IF NOT EXISTS bookings (" +
            "  id INT PRIMARY KEY AUTO_INCREMENT," +
            "  guest_id INT NOT NULL," +
            "  room_id INT NOT NULL," +
            "  check_in_date DATE NOT NULL," +
            "  check_out_date DATE NOT NULL," +
            "  total_amount DECIMAL(10,2) NOT NULL," +
            "  status VARCHAR(20) DEFAULT 'Confirmed'," +
            "  created_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
            "  FOREIGN KEY (guest_id) REFERENCES guests(id) ON DELETE CASCADE," +
            "  FOREIGN KEY (room_id)  REFERENCES rooms(id)  ON DELETE CASCADE" +
            ")",

            "CREATE TABLE IF NOT EXISTS employees (" +
            "  id INT PRIMARY KEY AUTO_INCREMENT," +
            "  name VARCHAR(255) NOT NULL," +
            "  role VARCHAR(100) NOT NULL," +
            "  salary DECIMAL(10,2) NOT NULL," +
            "  phone VARCHAR(20) NOT NULL," +
            "  hire_date DATE DEFAULT (CURDATE())" +
            ")",

            "CREATE TABLE IF NOT EXISTS users (" +
            "  id INT PRIMARY KEY AUTO_INCREMENT," +
            "  full_name VARCHAR(255) NOT NULL," +
            "  username VARCHAR(191) UNIQUE NOT NULL," +
            "  email VARCHAR(191) UNIQUE NOT NULL," +
            "  password VARCHAR(255) NOT NULL," +
            "  phone VARCHAR(20)," +
            "  role VARCHAR(50) NOT NULL," +
            "  balance DECIMAL(15,2) DEFAULT 100000.00," +
            "  created_at DATETIME DEFAULT CURRENT_TIMESTAMP" +
            ")",

            "CREATE TABLE IF NOT EXISTS notifications (" +
            "  id INT PRIMARY KEY AUTO_INCREMENT," +
            "  user_id INT NOT NULL," +
            "  message TEXT NOT NULL," +
            "  is_read BOOLEAN DEFAULT FALSE," +
            "  created_at DATETIME DEFAULT CURRENT_TIMESTAMP," +
            "  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE" +
            ")",

            // Seed rooms only if table is empty
            "INSERT IGNORE INTO rooms (room_number, type, price, status) VALUES " +
            "('101','Single',1000.0,'Available')," +
            "('102','Single',1000.0,'Available')," +
            "('201','Double',2000.0,'Available')," +
            "('202','Double',2000.0,'Available')," +
            "('301','Suite', 3500.0,'Available')," +
            "('401','Deluxe', 5000.0,'Available')," +
            "('501','Penthouse', 12000.0,'Available')"
        };

        executeStatements(ddl);
    }

    // ---------------------------------------------------------------
    // SQLite schema initialisation – uses INTEGER PRIMARY KEY (rowid
    // alias) and CURRENT_TIMESTAMP; no MySQL-only functions.
    // ---------------------------------------------------------------
    private static void initializeSQLiteSchema() {
        String[] ddl = {
            "CREATE TABLE IF NOT EXISTS guests (" +
            "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  name TEXT NOT NULL," +
            "  email TEXT UNIQUE," +
            "  phone TEXT NOT NULL," +
            "  address TEXT," +
            "  created_at TEXT DEFAULT (datetime('now','localtime'))" +
            ")",

            "CREATE TABLE IF NOT EXISTS rooms (" +
            "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  room_number TEXT NOT NULL UNIQUE," +
            "  type TEXT NOT NULL," +
            "  price REAL NOT NULL," +
            "  status TEXT DEFAULT 'Available'," +
            "  description TEXT" +
            ")",

            "CREATE TABLE IF NOT EXISTS bookings (" +
            "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  guest_id INTEGER NOT NULL," +
            "  room_id INTEGER NOT NULL," +
            "  check_in_date TEXT NOT NULL," +
            "  check_out_date TEXT NOT NULL," +
            "  total_amount REAL NOT NULL," +
            "  status TEXT DEFAULT 'Confirmed'," +
            "  created_at TEXT DEFAULT (datetime('now','localtime'))," +
            "  FOREIGN KEY (guest_id) REFERENCES guests(id) ON DELETE CASCADE," +
            "  FOREIGN KEY (room_id)  REFERENCES rooms(id)  ON DELETE CASCADE" +
            ")",

            "CREATE TABLE IF NOT EXISTS employees (" +
            "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  name TEXT NOT NULL," +
            "  role TEXT NOT NULL," +
            "  salary REAL NOT NULL," +
            "  phone TEXT NOT NULL," +
            "  hire_date TEXT DEFAULT (date('now','localtime'))" +
            ")",

            "CREATE TABLE IF NOT EXISTS users (" +
            "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  full_name TEXT NOT NULL," +
            "  username TEXT UNIQUE NOT NULL," +
            "  email TEXT UNIQUE NOT NULL," +
            "  password TEXT NOT NULL," +
            "  phone TEXT," +
            "  role TEXT NOT NULL," +
            "  balance REAL DEFAULT 100000.00," +
            "  created_at TEXT DEFAULT (datetime('now','localtime'))" +
            ")",

            "CREATE TABLE IF NOT EXISTS notifications (" +
            "  id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  user_id INTEGER NOT NULL," +
            "  message TEXT NOT NULL," +
            "  is_read INTEGER DEFAULT 0," +
            "  created_at TEXT DEFAULT (datetime('now','localtime'))," +
            "  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE" +
            ")",

            // Seed rooms (INSERT OR IGNORE is SQLite's equivalent of INSERT IGNORE)
            "INSERT OR IGNORE INTO rooms (room_number, type, price, status) VALUES " +
            "('101','Single',1000.0,'Available')",
            "INSERT OR IGNORE INTO rooms (room_number, type, price, status) VALUES " +
            "('102','Single',1000.0,'Available')",
            "INSERT OR IGNORE INTO rooms (room_number, type, price, status) VALUES " +
            "('201','Double',2000.0,'Available')",
            "INSERT OR IGNORE INTO rooms (room_number, type, price, status) VALUES " +
            "('202','Double',2000.0,'Available')",
            "INSERT OR IGNORE INTO rooms (room_number, type, price, status) VALUES " +
            "('301','Suite',3500.0,'Available')",
            "INSERT OR IGNORE INTO rooms (room_number, type, price, status) VALUES " +
            "('401','Deluxe',5000.0,'Available')",
            "INSERT OR IGNORE INTO rooms (room_number, type, price, status) VALUES " +
            "('501','Penthouse',12000.0,'Available')"
        };

        executeStatements(ddl);
    }

    private static void executeStatements(String[] statements) {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            for (String sql : statements) {
                if (sql != null && !sql.trim().isEmpty()) {
                    try {
                        stmt.execute(sql.trim());
                    } catch (SQLException ex) {
                        System.err.println("DDL warning (non-fatal): " + ex.getMessage());
                    }
                }
            }
            System.out.println("Schema initialised successfully.");
            
            // Migration: Ensure 'balance' column exists in 'users' table
            try {
                stmt.execute("ALTER TABLE users ADD COLUMN balance DECIMAL(15,2) DEFAULT 100000.00");
                System.out.println("Migration: Added 'balance' column to 'users' table.");
            } catch (SQLException e) {
                // Ignore if column already exists
            }
            
        } catch (SQLException e) {
            System.err.println("Fatal error initialising schema: " + e.getMessage());
        }
    }
}
