package com.hotel.model;

public class User {
    private int id;
    private String fullName;
    private String username;
    private String email;
    private String password;
    private String phone;
    private String role;
    private double balance;

    public User() {}

    public User(int id, String fullName, String username, String email, String password, String phone, String role) {
        this(id, fullName, username, email, password, phone, role, 100000.0);
    }

    public User(int id, String fullName, String username, String email, String password, String phone, String role, double balance) {
        this.id = id;
        this.fullName = fullName;
        this.username = username;
        this.email = email;
        this.password = password;
        this.phone = phone;
        this.role = role;
        this.balance = balance;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }
}
