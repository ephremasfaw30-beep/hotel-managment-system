package com.hotel;

import com.formdev.flatlaf.FlatLightLaf;
import com.hotel.gui.LoginFrame;
import javax.swing.*;
import java.awt.*;

/**
 * Main entry point for the Hotel Management System.
 */
public class Main {
    public static void main(String[] args) {
        // Setup modern FlatLaf Look and Feel with custom properties
        try {
            UIManager.put("Button.arc", 25);
            UIManager.put("Component.arc", 20);
            UIManager.put("TextComponent.arc", 20);
            UIManager.put("ScrollBar.thumbArc", 999);
            UIManager.put("ProgressBar.arc", 999);
            UIManager.put("Table.selectionBackground", new Color(0, 100, 0, 40));
            UIManager.put("Table.selectionForeground", Color.BLACK);
            UIManager.put("Component.focusWidth", 2);
            UIManager.put("Component.innerFocusWidth", 1);
            UIManager.put("Button.hoverBackground", new Color(240, 240, 240));
            UIManager.put("Button.innerFocusWidth", 0);
            
            FlatLightLaf.setup();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Start the application with the Login screen
        SwingUtilities.invokeLater(() -> {
            new LoginFrame().setVisible(true);
        });
    }
}
